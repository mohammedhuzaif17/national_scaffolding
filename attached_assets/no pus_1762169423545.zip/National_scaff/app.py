from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
import sqlite3
import os
import base64
import time
import json
import re

app = Flask(__name__)
app.secret_key = os.getenv('SESSION_SECRET', 'creta-tech-secret-key-2024')

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

DATABASE = 'creta_technology.db'

# Currency Configuration (Embedded directly in app.py)
class CurrencyConfig:
    # Currency settings
    DEFAULT_CURRENCY = "INR"
    CURRENCY_SYMBOL = "₹"
    USD_TO_INR_RATE = 83  # Update this rate regularly
    
    # Price formatting
    SHOW_DECIMALS = False
    LOCALE = "en-IN"  # For proper Indian number formatting
    
    @classmethod
    def convert_to_inr(cls, usd_amount):
        """Convert USD amount to INR"""
        return round(usd_amount * cls.USD_TO_INR_RATE)
    
    @classmethod
    def format_price(cls, amount):
        """Format price according to currency settings"""
        if cls.SHOW_DECIMALS:
            return f"{cls.CURRENCY_SYMBOL}{amount:.2f}"
        else:
            return f"{cls.CURRENCY_SYMBOL}{amount:,}"

# Add currency template filters
@app.template_filter('inr')
def inr_filter(usd_amount):
    """Convert USD to INR and format"""
    inr_amount = CurrencyConfig.convert_to_inr(usd_amount)
    return CurrencyConfig.format_price(inr_amount)

@app.template_filter('inr_value')
def inr_value_filter(usd_amount):
    """Convert USD to INR without symbol"""
    return CurrencyConfig.convert_to_inr(usd_amount)

# Add currency context to all templates
@app.context_processor
def inject_currency():
    return {
        'currency_symbol': CurrencyConfig.CURRENCY_SYMBOL,
        'currency_code': CurrencyConfig.DEFAULT_CURRENCY,
        'usd_to_inr_rate': CurrencyConfig.USD_TO_INR_RATE
    }

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_image_from_base64(base64_data, prefix="camera_capture"):
    try:
        if ',' in base64_data:
            header, base64_data = base64_data.split(',', 1)
        image_data = base64.b64decode(base64_data)
        timestamp = str(int(time.time()))
        filename = f"{prefix}_{timestamp}.jpg"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        with open(filepath, 'wb') as f:
            f.write(image_data)
        
        return url_for('static', filename=f'uploads/{filename}')
    except Exception as e:
        print(f"Error saving base64 image: {e}")
        return None

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database with required tables if they don't exist"""
    conn = get_db()
    cursor = conn.cursor()
    
    # Create users table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT UNIQUE NOT NULL,
            address TEXT,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create products table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            description TEXT,
            category TEXT NOT NULL,
            subcategory TEXT,
            customizable INTEGER DEFAULT 0,
            stock_quantity INTEGER DEFAULT 0,
            available_for_rent INTEGER DEFAULT 0,
            rent_price REAL DEFAULT 0,
            security_deposit REAL DEFAULT 0,
            late_return_fine REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create product_images table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS product_images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            image_url TEXT NOT NULL,
            is_primary INTEGER DEFAULT 0,
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')
    
    # Create cart table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            transaction_type TEXT DEFAULT 'buy',
            customization TEXT,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')
    
    # Create orders table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            product_price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            total_price REAL NOT NULL,
            status TEXT DEFAULT 'pending',
            transaction_type TEXT DEFAULT 'buy',
            customization TEXT,
            username TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT,
            ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')
    
    # Check if columns exist and add them if they don't
    cursor.execute("PRAGMA table_info(products)")
    columns = [column[1] for column in cursor.fetchall()]
    
    if 'subcategory' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN subcategory TEXT")
        conn.commit()
        print("Added subcategory column to products table")
    
    if 'customizable' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN customizable INTEGER DEFAULT 0")
        conn.commit()
        print("Added customizable column to products table")
    
    if 'stock_quantity' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN stock_quantity INTEGER DEFAULT 0")
        conn.commit()
        print("Added stock_quantity column to products table")
    
    if 'available_for_rent' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN available_for_rent INTEGER DEFAULT 0")
        conn.commit()
        print("Added available_for_rent column to products table")
    
    if 'rent_price' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN rent_price REAL DEFAULT 0")
        conn.commit()
        print("Added rent_price column to products table")
    
    if 'security_deposit' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN security_deposit REAL DEFAULT 0")
        conn.commit()
        print("Added security_deposit column to products table")
    
    if 'late_return_fine' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN late_return_fine REAL DEFAULT 0")
        conn.commit()
        print("Added late_return_fine column to products table")
    
    if 'created_at' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
        conn.commit()
        print("Added created_at column to products table")
    
    # Check if columns exist in cart table
    cursor.execute("PRAGMA table_info(cart)")
    cart_columns = [column[1] for column in cursor.fetchall()]
    
    if 'transaction_type' not in cart_columns:
        cursor.execute("ALTER TABLE cart ADD COLUMN transaction_type TEXT DEFAULT 'buy'")
        conn.commit()
        print("Added transaction_type column to cart table")
    
    if 'customization' not in cart_columns:
        cursor.execute("ALTER TABLE cart ADD COLUMN customization TEXT")
        conn.commit()
        print("Added customization column to cart table")
    
    # Check if columns exist in orders table
    cursor.execute("PRAGMA table_info(orders)")
    order_columns = [column[1] for column in cursor.fetchall()]
    
    if 'transaction_type' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN transaction_type TEXT DEFAULT 'buy'")
        conn.commit()
        print("Added transaction_type column to orders table")
    
    if 'customization' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN customization TEXT")
        conn.commit()
        print("Added customization column to orders table")
    
    if 'username' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN username TEXT")
        conn.commit()
        print("Added username column to orders table")
    
    if 'email' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN email TEXT")
        conn.commit()
        print("Added email column to orders table")
    
    if 'phone' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN phone TEXT")
        conn.commit()
        print("Added phone column to orders table")
    
    if 'address' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN address TEXT")
        conn.commit()
        print("Added address column to orders table")
    
    # Create default admin user if not exists
    cursor.execute('SELECT * FROM users WHERE role = "admin"')
    if not cursor.fetchone():
        hashed_password = generate_password_hash('admin123')
        cursor.execute('''
            INSERT INTO users (username, email, phone, address, password, role) 
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('admin', 'admin@national-scaffolding.com', '+918105934475', 'Bengaluru, Karnataka', hashed_password, 'admin'))
        conn.commit()
        print("Created default admin user: admin / admin123")
    
    # Create test user if not exists
    cursor.execute('SELECT * FROM users WHERE username = "test_user"')
    if not cursor.fetchone():
        hashed_password = generate_password_hash('password123')
        cursor.execute('''
            INSERT INTO users (username, email, phone, address, password, role) 
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('test_user', 'test@example.com', '+919876543212', '123 Test Street, Test City', hashed_password, 'user'))
        conn.commit()
        print("Created test user: test_user / password123")
    
    # Add sample products if none exist
    cursor.execute('SELECT COUNT(*) FROM products')
    if cursor.fetchone()[0] == 0:
        # Add sample H-Frame Product (Customizable)
        cursor.execute('''
            INSERT INTO products (name, price, description, category, subcategory, customizable, available_for_rent, rent_price, security_deposit, stock_quantity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', 
        ("Aluminium H-Frame (Customizable)", 1500.00, "High-quality, customizable aluminium H-frame for all construction needs. Perfect for versatile scaffolding solutions.", 'scaffolding', 'hframes', 1, 1, 150.00, 1500.00, 100))
        
        h_frame_id = cursor.lastrowid
        
        # Add placeholder image for H-Frame
        cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                      (h_frame_id, url_for('static', filename='images/product-placeholder.jpg'), 1))
        
        # Add sample Cuplock Product
        cursor.execute('''
            INSERT INTO products (name, price, description, category, subcategory, customizable, available_for_rent, rent_price, security_deposit, stock_quantity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', 
        ("Cuplock System Standard", 1800.00, "Robust cuplock scaffolding system for high-load applications and complex structures.", 'scaffolding', 'cuplock', 0, 1, 200.00, 1800.00, 75))
        
        cuplock_id = cursor.lastrowid
        
        # Add placeholder image for Cuplock
        cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                      (cuplock_id, url_for('static', filename='images/product-placeholder.jpg'), 1))
        
        # Add sample Aluminium Product (Non-Customizable)
        cursor.execute('''
            INSERT INTO products (name, price, description, category, subcategory, customizable, available_for_rent, stock_quantity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', 
        ("Aluminium Mobile Tower", 25000.00, "Complete mobile tower unit with casters for easy movement. Ready to use out of the box.", 'scaffolding', 'aluminium', 0, 0, 15))
        
        aluminium_id = cursor.lastrowid
        
        # Add placeholder image for Aluminium Tower
        cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                      (aluminium_id, url_for('static', filename='images/product-placeholder.jpg'), 1))
        
        conn.commit()
        print("Added sample products")
    
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            # Store the URL the user was trying to access
            session['next_url'] = request.url
            flash('Please log in to access this page', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Auto-categorization function for scaffolding products
def auto_categorize_scaffolding(name, description):
    """
    Automatically categorize scaffolding products based on keywords in name and description.
    Returns one of: 'aluminium', 'hframes', 'cuplock', or 'other'
    """
    # Combine name and description for checking
    text = (name + ' ' + description).lower()
    
    # Check for H Frames keywords
    h_frame_keywords = ['h frame', 'h-frame', 'hframe', 'h frames', 'h-frames']
    for keyword in h_frame_keywords:
        if keyword in text:
            return 'hframes'
    
    # Check for Aluminium keywords
    aluminium_keywords = ['aluminium', 'aluminum', 'aluminio']
    for keyword in aluminium_keywords:
        if keyword in text:
            return 'aluminium'
    
    # Check for Cuplock keywords
    cuplock_keywords = ['cuplock', 'cup lock', 'cup-lock']
    for keyword in cuplock_keywords:
        if keyword in text:
            return 'cuplock'
    
    # Default category if no keywords match
    return 'other'

def get_product_images(product_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT image_url FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, id', (product_id,))
    images = cursor.fetchall()
    conn.close()
    
    # Return list of image URLs
    return [img['image_url'] for img in images]

def get_primary_image(product_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT image_url FROM product_images WHERE product_id = ? AND is_primary = 1 LIMIT 1', (product_id,))
    image = cursor.fetchone()
    conn.close()
    
    if image:
        return image['image_url']
    
    # Return a default placeholder if no image is found
    return url_for('static', filename='images/product-placeholder.jpg')

def get_products_with_images(subcategory=None):
    conn = get_db()
    cursor = conn.cursor()

    if subcategory:
        cursor.execute('''
            SELECT p.*, GROUP_CONCAT(pi.image_url) as images
            FROM products p
            LEFT JOIN product_images pi ON p.id = pi.product_id
            WHERE p.subcategory = ?
            GROUP BY p.id
        ''', (subcategory,))
    else:
        cursor.execute('''
            SELECT p.*, GROUP_CONCAT(pi.image_url) as images
            FROM products p
            LEFT JOIN product_images pi ON p.id = pi.product_id
            GROUP BY p.id
        ''')

    products = cursor.fetchall()
    conn.close()

    # Convert the comma-separated image URLs back into a list
    product_list = []
    for product in products:
        product_dict = dict(product)
        if product_dict['images']:
            product_dict['images'] = product_dict['images'].split(',')
        else:
            product_dict['images'] = []
        product_list.append(product_dict)

    return product_list

@app.route('/')
def index():
    # Initialize database to ensure all columns exist
    init_db()
    
    # Check if user is already logged in
    if session.get('logged_in'):
        # If user is logged in, redirect based on their role
        if session.get('role') == 'admin':
            return redirect(url_for('admin_scaffolding'))
        elif session.get('role') == 'user':
            return redirect(url_for('national_scaffolding'))
    
    # If not logged in, show the landing page with products
    products = get_products_with_images()
    return render_template('index.html', show_popup=True, products=products)

@app.route('/login', methods=['GET', 'POST'])
def login():
    # If already logged in, redirect to appropriate page
    if session.get('logged_in'):
        if session.get('role') == 'admin':
            return redirect(url_for('admin_scaffolding'))
        else:
            return redirect(url_for('national_scaffolding'))
    
    if request.method == 'POST':
        login_identifier = request.form['login_identifier'].strip()
        password = request.form['password']
        
        # Debug: Print the login attempt
        print(f"Login attempt: {login_identifier}")
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Check if the users table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if not cursor.fetchone():
            flash('Database not initialized. Please restart the application.', 'error')
            conn.close()
            return render_template('login.html')
        
        phone = re.sub(r'\D', '', login_identifier)
        if len(phone) == 10 and re.match(r'^[6-9]', phone):
            cursor.execute('SELECT * FROM users WHERE phone = ? OR phone = ?', (phone, '+91' + phone))
        else:
            cursor.execute('SELECT * FROM users WHERE username = ? OR email = ?', (login_identifier, login_identifier))
        
        user = cursor.fetchone()
        
        # Debug: Print if user was found
        if user:
            print(f"User found: {user['username']}, Role: {user['role']}")
        else:
            print("User not found")
        
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            # Clear any existing session data
            session.clear()
            
            # Set new session data
            session['logged_in'] = True
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            
            flash('Login successful!', 'success')
            
            # Check if there's a stored next URL to redirect to
            next_url = session.pop('next_url', None)
            if next_url:
                return redirect(next_url)
            
            if user['role'] == 'admin':
                return redirect(url_for('admin_scaffolding'))
            else:
                # Redirect regular users to national scaffolding page
                return redirect(url_for('national_scaffolding'))
        else:
            flash('Invalid credentials. Please try again.', 'error')
    
    return render_template('login.html')

# Add these routes to your app.py file

@app.route('/payment')
@login_required
def payment():
    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    
    # Get cart items with product details
    cursor.execute('''
        SELECT c.id, c.quantity, c.transaction_type, c.customization,
               p.id as product_id, p.name, p.price, p.description, p.category
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ''', (user_id,))
    
    cart_items = cursor.fetchall()
    cart_items_with_images = []
    
    for item in cart_items:
        item_dict = dict(item)
        item_dict['primary_image'] = get_primary_image(item['product_id'])
        
        # Parse customization if exists
        if item_dict['customization']:
            try:
                item_dict['customization_data'] = json.loads(item_dict['customization'])
            except:
                item_dict['customization_data'] = {}
        else:
            item_dict['customization_data'] = {}
        
        cart_items_with_images.append(item_dict)
    
    conn.close()
    
    # Calculate total
    total = 0
    for item in cart_items_with_images:
        item_price = item['price']
        
        # Add customization price if exists
        if item['customization_data'] and 'customization_price' in item['customization_data']:
            item_price += item['customization_data']['customization_price']
        
        # Apply discount if exists
        if item['customization_data'] and 'discount_amount' in item['customization_data']:
            item_price -= item['customization_data']['discount_amount']
        
        total += item_price * item['quantity']
    
    return render_template('payment.html', cart_items=cart_items_with_images, total=total)

@app.route('/payment/qr-scanner')
@login_required
def payment_qr_scanner():
    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    
    # Get cart items with product details
    cursor.execute('''
        SELECT c.id, c.quantity, c.transaction_type, c.customization,
               p.id as product_id, p.name, p.price, p.description, p.category
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ''', (user_id,))
    
    cart_items = cursor.fetchall()
    cart_items_with_images = []
    
    for item in cart_items:
        item_dict = dict(item)
        item_dict['primary_image'] = get_primary_image(item['product_id'])
        
        # Parse customization if exists
        if item_dict['customization']:
            try:
                item_dict['customization_data'] = json.loads(item_dict['customization'])
            except:
                item_dict['customization_data'] = {}
        else:
            item_dict['customization_data'] = {}
        
        cart_items_with_images.append(item_dict)
    
    conn.close()
    
    # Calculate total
    total = 0
    for item in cart_items_with_images:
        item_price = item['price']
        
        # Add customization price if exists
        if item['customization_data'] and 'customization_price' in item['customization_data']:
            item_price += item['customization_data']['customization_price']
        
        # Apply discount if exists
        if item['customization_data'] and 'discount_amount' in item['customization_data']:
            item_price -= item['customization_data']['discount_amount']
        
        total += item_price * item['quantity']
    
    return render_template('payment_qr_scanner.html', cart_items=cart_items_with_images, total=total)

@app.route('/payment/process')
@login_required
def process_payment():
    # Process the order after payment confirmation
    return checkout()

@app.route('/payment/cod')
@login_required
def process_cod_order():
    # Process cash on delivery order
    return checkout()
    
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        email = request.form['email'].strip()
        phone = request.form['phone'].strip()
        address = request.form['address'].strip()
        password = request.form['password']
        
        phone = re.sub(r'\D', '', phone)
        if len(phone) == 10:
            phone = '+91' + phone
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        if cursor.fetchone():
            flash('Username already exists', 'error')
            conn.close()
            return redirect(url_for('register'))
        
        cursor.execute('SELECT * FROM users WHERE email = ?', (email,))
        if cursor.fetchone():
            flash('Email already exists', 'error')
            conn.close()
            return redirect(url_for('register'))
        
        cursor.execute('SELECT * FROM users WHERE phone = ?', (phone,))
        if cursor.fetchone():
            flash('Phone number already exists', 'error')
            conn.close()
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password)
        cursor.execute('INSERT INTO users (username, email, phone, address, password, role) VALUES (?, ?, ?, ?, ?, ?)',
                      (username, email, phone, address, hashed_password, 'user'))
        conn.commit()
        conn.close()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'success')
    return redirect(url_for('index'))

@app.route('/national_scaffolding')
def national_scaffolding():
    # Allow all users (logged in or not) to view the products
    products = get_products_with_images()
    return render_template('national_scaffolding.html', products=products)

@app.route('/aluminium-scaffoldings')
def aluminium_scaffoldings():
    # Get only Aluminium products
    products = get_products_with_images(subcategory='aluminium')
    return render_template('aluminium_scaffoldings.html', products=products)

@app.route('/h-frames-scaffoldings')
def h_frames_scaffoldings():
    # Get only H frames products
    products = get_products_with_images(subcategory='hframes')
    return render_template('h_frames_scaffoldings.html', products=products)

@app.route('/cuplock-scaffoldings')
def cuplock_scaffoldings():
    # Get only Cuplock products
    products = get_products_with_images(subcategory='cuplock')
    return render_template('cuplock_scaffoldings.html', products=products)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    # Get transaction_type from query parameter (default to 'buy')
    transaction_type = request.args.get('transaction_type', 'buy')
    
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('''
        SELECT p.*, GROUP_CONCAT(pi.image_url) as images
        FROM products p
        LEFT JOIN product_images pi ON p.id = pi.product_id
        WHERE p.id = ?
        GROUP BY p.id
    ''', (product_id,))
    
    product = cursor.fetchone()
    conn.close()

    if product is None:
        abort(404)

    product_dict = dict(product)
    if product_dict['images']:
        product_dict['images'] = product_dict['images'].split(',')
    else:
        product_dict['images'] = []

    # Check if product is customizable and redirect if needed
    if product_dict['customizable']:
        # Pass transaction_type to custom_product_detail
        return redirect(url_for('custom_product_detail', product_id=product_id) + f'?transaction_type={transaction_type}')
    
    # Pass transaction_type to regular product_detail template    
    return render_template('product_detail.html', product=product_dict, transaction_type=transaction_type)
@app.route('/qr-scanner')
@login_required
def qr_scanner():
    if session.get('role') != 'user':
        flash('Unauthorized access', 'error')
        return redirect(url_for('index'))
    
    return render_template('qr_scanner.html')

@app.route('/cctv-solutions')
def cctv_solutions():
    # Get CCTV products or render CCTV page
    return render_template('cctv_solutions.html')

@app.route('/product/<int:product_id>/custom')
def custom_product_detail(product_id):
    # Get transaction_type from query parameter (default to 'buy')
    transaction_type = request.args.get('transaction_type', 'buy')
    
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('''
        SELECT p.*, GROUP_CONCAT(pi.image_url) as images
        FROM products p
        LEFT JOIN product_images pi ON p.id = pi.product_id
        WHERE p.id = ? AND p.customizable = 1
        GROUP BY p.id
    ''', (product_id,))
    
    product = cursor.fetchone()
    conn.close()

    if product is None:
        abort(404) # Not found or not customizable

    product_dict = dict(product)
    if product_dict['images']:
        product_dict['images'] = product_dict['images'].split(',')
    else:
        product_dict['images'] = []
    
    # Pass both product and transaction_type to template
    return render_template('custom_product_detail.html', 
                         product=product_dict, 
                         transaction_type=transaction_type)

@app.route('/add-custom-to-cart/<int:product_id>', methods=['POST'])
@login_required
def add_custom_to_cart(product_id):
    if session.get('role') != 'user':
        flash('Only users can add products to cart', 'danger')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,))
    product = cursor.fetchone()
    
    if not product or not product['customizable']:
        conn.close()
        return redirect(url_for('product_detail', product_id=product_id))
    
    # Get customization options
    height = request.form.get('height')
    width = request.form.get('width')
    gauge = request.form.get('gauge')
    quantity = int(request.form.get('quantity', 1))
    customization_price = float(request.form.get('customization_price', 0))
    discount_percent = float(request.form.get('discount_percent', 0))
    discount_amount = float(request.form.get('discount_amount', 0))
    total_price = float(request.form.get('total_price'))
    transaction_type = request.form.get('transaction_type', 'buy')
    
    # Create a custom product ID based on options
    custom_id = f"{product_id}_{height}_{width}_{gauge}"
    
    # Create customization JSON
    customization = {
        'height': height,
        'width': width,
        'gauge': gauge,
        'customization_price': customization_price,
        'discount_percent': discount_percent,
        'discount_amount': discount_amount
    }
    
    # Check if item already exists in cart
    cursor.execute('''
        SELECT * FROM cart 
        WHERE user_id = ? AND product_id = ? AND customization = ? AND transaction_type = ?
    ''', (session['user_id'], product_id, json.dumps(customization), transaction_type))
    
    existing_item = cursor.fetchone()
    
    if existing_item:
        # Update existing item
        new_quantity = existing_item['quantity'] + quantity
        cursor.execute('''
            UPDATE cart SET quantity = ?
            WHERE id = ?
        ''', (new_quantity, existing_item['id']))
    else:
        # Add new item
        cursor.execute('''
            INSERT INTO cart (user_id, product_id, quantity, transaction_type, customization)
            VALUES (?, ?, ?, ?, ?)
        ''', (session['user_id'], product_id, quantity, transaction_type, json.dumps(customization)))
    
    conn.commit()
    conn.close()
    
    flash('Product added to cart!', 'success')
    return redirect(url_for('view_cart'))

@app.route('/user-dashboard')
@login_required
def user_dashboard():
    # If an admin accidentally lands here, redirect them to their own dashboard
    if session.get('role') == 'admin':
        return redirect(url_for('admin_scaffolding'))
    
    # If a non-user role lands here (e.g., a future 'manager' role), redirect to index
    if session.get('role') != 'user':
        flash('Unauthorized access', 'error')
        return redirect(url_for('index'))
    
    # Render the user dashboard for regular users
    return render_template('user_dashboard.html')

@app.route('/admin/scaffolding')
@login_required
def admin_scaffolding():
    if session.get('role') != 'admin':
        flash('Unauthorized access', 'error')
        return redirect(url_for('index'))
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM products WHERE category = ? ORDER BY created_at DESC', ('scaffolding',))
    products = cursor.fetchall()
    
    products_with_images = []
    for product in products:
        images = get_product_images(product['id'])
        product_dict = dict(product)
        product_dict['images'] = images
        products_with_images.append(product_dict)
    
    cursor.execute('''
        SELECT o.*, u.username, u.email, u.phone, u.address
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN products p ON o.product_id = p.id
        WHERE p.category = ?
        ORDER BY o.ordered_at DESC
    ''', ('scaffolding',))
    orders = cursor.fetchall()
    conn.close()
    return render_template('admin_scaffolding.html', products=products_with_images, orders=orders)

@app.route('/admin/add-product', methods=['POST'])
@login_required
def add_product():
    if session.get('role') != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    name = request.form.get('name')
    # Convert INR to USD for storage
    price_inr = float(request.form.get('price'))
    price = price_inr / CurrencyConfig.USD_TO_INR_RATE
    
    description = request.form.get('description')
    category = 'scaffolding'
    subcategory = request.form.get('subcategory')
    customizable = request.form.get('customizable') == 'on'
    available_for_rent = request.form.get('available_for_rent') == 'on'
    
    # Handle rental options
    rent_price = 0
    security_deposit = 0
    late_return_fine = 0
    
    if available_for_rent:
        rent_price_inr = float(request.form.get('rent_price', 0))
        security_deposit_inr = float(request.form.get('security_deposit', 0))
        late_return_fine_inr = float(request.form.get('late_return_fine', 0))
        
        # Convert to USD for storage
        rent_price = rent_price_inr / CurrencyConfig.USD_TO_INR_RATE
        security_deposit = security_deposit_inr / CurrencyConfig.USD_TO_INR_RATE
        late_return_fine = late_return_fine_inr / CurrencyConfig.USD_TO_INR_RATE
    
    conn = get_db()
    cursor = conn.cursor()
    
    # Add product with subcategory and rental info
    cursor.execute('''
        INSERT INTO products (name, price, description, category, subcategory, customizable,
                              available_for_rent, rent_price, security_deposit, late_return_fine) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, price, description, category, subcategory, customizable, available_for_rent, 
          rent_price, security_deposit, late_return_fine))
    
    product_id = cursor.lastrowid
    
    image_urls = []
    if 'product_images' in request.files:
        files = request.files.getlist('product_images')
        for i, file in enumerate(files):
            if file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                timestamp = str(int(time.time()))
                filename = f"{timestamp}_{i}_{filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                image_url = url_for('static', filename=f'uploads/{filename}')
                image_urls.append(image_url)
    
    image_data_list = request.form.get('image_data_list')
    if image_data_list:
        try:
            all_images = json.loads(image_data_list)
            for image in all_images:
                if image.get('data'):
                    image_url = save_image_from_base64(image['data'], f"camera_capture_{image.get('id', 'unknown')}")
                    if image_url:
                        image_urls.append(image_url)
        except json.JSONDecodeError:
            print("Error decoding image data JSON")
    
    for i, image_url in enumerate(image_urls):
        is_primary = 1 if i == 0 else 0
        cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                      (product_id, image_url, is_primary))
    
    conn.commit()
    conn.close()
    
    flash('Product added successfully!', 'success')
    return redirect(url_for('admin_scaffolding'))

@app.route('/admin/edit-product/<int:product_id>', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    if session.get('role') != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    # Get product details
    cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,))
    product = cursor.fetchone()
    
    if not product:
        conn.close()
        flash('Product not found', 'error')
        return redirect(url_for('admin_scaffolding'))
    
    # Get product images
    images = get_product_images(product_id)
    product_dict = dict(product)
    product_dict['images'] = images
    
    if request.method == 'POST':
        # Update product details
        name = request.form['name']
        # Convert INR to USD for storage
        price_inr = float(request.form['price'])
        price = price_inr / CurrencyConfig.USD_TO_INR_RATE
        
        description = request.form['description']
        subcategory = request.form.get('subcategory')
        customizable = request.form.get('customizable') == 'on'
        available_for_rent = 'available_for_rent' in request.form
        
        rent_price = 0
        security_deposit = 0
        late_return_fine = 0
        
        if available_for_rent:
            rent_price_inr = float(request.form.get('rent_price', 0))
            security_deposit_inr = float(request.form.get('security_deposit', 0))
            late_return_fine_inr = float(request.form.get('late_return_fine', 0))
            
            # Convert to USD for storage
            rent_price = rent_price_inr / CurrencyConfig.USD_TO_INR_RATE
            security_deposit = security_deposit_inr / CurrencyConfig.USD_TO_INR_RATE
            late_return_fine = late_return_fine_inr / CurrencyConfig.USD_TO_INR_RATE
        
        # Update product in database
        cursor.execute('''
            UPDATE products 
            SET name = ?, price = ?, description = ?, subcategory = ?, customizable = ?, 
                available_for_rent = ?, rent_price = ?, security_deposit = ?, late_return_fine = ?
            WHERE id = ?
        ''', (name, price, description, subcategory, customizable, available_for_rent, 
              rent_price, security_deposit, late_return_fine, product_id))
        
        # Handle image uploads
        image_urls = []
        if 'product_images' in request.files:
            files = request.files.getlist('product_images')
            for i, file in enumerate(files):
                if file.filename != '' and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    timestamp = str(int(time.time()))
                    filename = f"{timestamp}_{i}_{filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    image_url = url_for('static', filename=f'uploads/{filename}')
                    image_urls.append(image_url)
        
        # Handle camera images
        image_data_list = request.form.get('image_data_list')
        if image_data_list:
            try:
                all_images = json.loads(image_data_list)
                for image in all_images:
                    if image.get('data'):
                        image_url = save_image_from_base64(image['data'], f"camera_capture_{image.get('id', 'unknown')}")
                        if image_url:
                            image_urls.append(image_url)
            except json.JSONDecodeError:
                print("Error decoding image data JSON")
        
        # Add new images to database
        for i, image_url in enumerate(image_urls):
            is_primary = 1 if i == 0 and not images else 0
            cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                          (product_id, image_url, is_primary))
        
        conn.commit()
        conn.close()
        flash('Product updated successfully', 'success')
        return redirect(url_for('admin_scaffolding'))
    
    conn.close()
    return render_template('edit_product.html', product=product_dict)

@app.route('/admin/delete-product/<int:product_id>', methods=['POST'])
@login_required
def delete_product(product_id):
    if session.get('role') != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT image_url FROM product_images WHERE product_id = ?', (product_id,))
    images = cursor.fetchall()
    for image in images:
        try:
            filename = image['image_url'].split('/')[-1]
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            if os.path.exists(filepath):
                os.remove(filepath)
        except Exception as e:
            print(f"Error deleting image file: {e}")
    
    cursor.execute('DELETE FROM products WHERE id = ?', (product_id,))
    conn.commit()
    conn.close()
    flash('Product deleted successfully', 'success')
    return redirect(url_for('admin_scaffolding'))

@app.route('/cart')
@login_required
def view_cart():
    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    
    # Get cart items with product details
    cursor.execute('''
        SELECT c.id, c.quantity, c.transaction_type, c.customization,
               p.id as product_id, p.name, p.price, p.description, p.category
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ''', (user_id,))
    
    cart_items = cursor.fetchall()
    cart_items_with_images = []
    
    for item in cart_items:
        item_dict = dict(item)
        item_dict['primary_image'] = get_primary_image(item['product_id'])
        
        # Parse customization if exists
        if item_dict['customization']:
            try:
                item_dict['customization_data'] = json.loads(item_dict['customization'])
            except:
                item_dict['customization_data'] = {}
        else:
            item_dict['customization_data'] = {}
        
        cart_items_with_images.append(item_dict)
    
    conn.close()
    
    # Calculate total
    total = 0
    for item in cart_items_with_images:
        item_price = item['price']
        
        # Add customization price if exists
        if item['customization_data'] and 'customization_price' in item['customization_data']:
            item_price += item['customization_data']['customization_price']
        
        # Apply discount if exists
        if item['customization_data'] and 'discount_amount' in item['customization_data']:
            item_price -= item['customization_data']['discount_amount']
        
        total += item_price * item['quantity']
    
    return render_template('cart.html', cart_items=cart_items_with_images, total=total)

@app.route('/cart/add/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    # Check if user is logged in
    if not session.get('logged_in'):
        # Store the product ID and redirect to login
        session['pending_product_id'] = product_id
        flash('Please log in to add items to your cart', 'info')
        return jsonify({'success': False, 'login_required': True, 'message': 'Please log in to add items to your cart'})
    
    user_id = session.get('user_id')
    transaction_type = request.form.get('transaction_type', 'buy')
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,))
    product = cursor.fetchone()
    
    if not product:
        conn.close()
        return jsonify({'success': False, 'message': 'Product not found'})
    
    # Check if product is customizable
    if product['customizable']:
        conn.close()
        return jsonify({'success': False, 'customizable': True, 'message': 'This product requires customization'})
    
    # Get customization data from form
    customization = {}
    
    # Handle H Frames customization
    if request.form.get('gauge'):
        customization['gauge'] = request.form.get('gauge')
        customization['customization_price'] = float(request.form.get('customization_price', 0))
        customization['discount_percent'] = float(request.form.get('discount_percent', 0))
        customization['discount_amount'] = float(request.form.get('discount_amount', 0))
    
    # Handle Cuplock customization
    if request.form.get('weight'):
        customization['weight'] = float(request.form.get('weight'))
        customization['weight_cost'] = float(request.form.get('weight_cost', 0))
        customization['discount_percent'] = float(request.form.get('discount_percent', 0))
        customization['discount_amount'] = float(request.form.get('discount_amount', 0))
    
    # Check if item already exists in cart
    cursor.execute('''
        SELECT * FROM cart 
        WHERE user_id = ? AND product_id = ? AND customization = ? AND transaction_type = ?
    ''', (user_id, product_id, json.dumps(customization), transaction_type))
    
    existing_item = cursor.fetchone()
    
    if existing_item:
        # Update existing item
        new_quantity = existing_item['quantity'] + int(request.form.get('quantity', 1))
        cursor.execute('''
            UPDATE cart SET quantity = ?
            WHERE id = ?
        ''', (new_quantity, existing_item['id']))
    else:
        # Add new item
        cursor.execute('''
            INSERT INTO cart (user_id, product_id, quantity, transaction_type, customization)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, product_id, int(request.form.get('quantity', 1)), transaction_type, json.dumps(customization)))
    
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Product added to cart'})

@app.route('/cart/remove/<int:cart_id>', methods=['POST'])
@login_required
def remove_from_cart(cart_id):
    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM cart WHERE id = ? AND user_id = ?', (cart_id, user_id))
    conn.commit()
    conn.close()
    flash('Item removed from cart', 'success')
    return redirect(url_for('view_cart'))

# RENAMED FUNCTION: For form submissions from cart.html
@app.route('/cart/update/<int:cart_id>', methods=['POST'])
@login_required
def update_cart_quantity_form(cart_id):
    user_id = session.get('user_id')
    quantity = int(request.form.get('quantity', 1))
    if quantity < 1:
        flash('Quantity must be at least 1', 'error')
        return redirect(url_for('view_cart'))
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?', (quantity, cart_id, user_id))
    conn.commit()
    conn.close()
    flash('Cart updated', 'success')
    return redirect(url_for('view_cart'))

@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    
    # Get user details
    cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    
    # Get cart items
    cursor.execute('''
        SELECT c.*, p.name, p.price
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = ?
    ''', (user_id,))
    
    cart_items = cursor.fetchall()
    
    if not cart_items:
        conn.close()
        flash('Your cart is empty', 'error')
        return redirect(url_for('view_cart'))
    
    # Process each cart item as an order
    for item in cart_items:
        # Calculate total price
        item_price = item['price']
        
        # Add customization price if exists
        if item['customization']:
            try:
                customization = json.loads(item['customization'])
                if 'customization_price' in customization:
                    item_price += customization['customization_price']
                if 'discount_amount' in customization:
                    item_price -= customization['discount_amount']
                if 'weight_cost' in customization:
                    item_price += customization['weight_cost']
            except:
                pass
        
        total_price = item_price * item['quantity']
        
        # Insert order
        cursor.execute('''
            INSERT INTO orders (user_id, product_id, product_name, product_price, 
                              quantity, total_price, status, transaction_type, 
                              customization, username, email, phone, address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, item['product_id'], item['name'], item['price'], 
              item['quantity'], total_price, 'pending', item['transaction_type'],
              item['customization'], user['username'], user['email'], 
              user['phone'], user['address']))
    
    # Clear cart
    cursor.execute('DELETE FROM cart WHERE user_id = ?', (user_id,))
    conn.commit()
    conn.close()
    
    flash('Order placed successfully! Admin will review your order.', 'success')
    return redirect(url_for('my_orders'))

@app.route('/my-orders')
@login_required
def my_orders():
    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT o.* FROM orders o WHERE o.user_id = ? ORDER BY o.ordered_at DESC', (user_id,))
    orders = cursor.fetchall()
    
    orders_with_images = []
    for order in orders:
        order_dict = dict(order)
        order_dict['primary_image'] = get_primary_image(order['product_id'])
        orders_with_images.append(order_dict)
    
    conn.close()
    return render_template('my_orders.html', orders=orders_with_images)

@app.route('/cart-count')
def cart_count():
    try:
        # Check if user is logged in
        if not session.get('logged_in') or session.get('role') != 'user':
            return jsonify({'count': 0})
            
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'count': 0})
            
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) as count FROM cart WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        conn.close()
        
        count = result['count'] if result else 0
        return jsonify({'count': count})
    except Exception as e:
        print(f"Cart count error: {e}")
        return jsonify({'count': 0})

@app.route('/admin/update-order-status/<int:order_id>', methods=['POST'])
@login_required
def update_order_status(order_id):
    if session.get('role') != 'admin':
        flash('Unauthorized', 'error')
        return redirect(url_for('national_scaffolding'))
    
    new_status = request.form.get('status')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE orders SET status = ? WHERE id = ?', (new_status, order_id))
    conn.commit()
    conn.close()
    flash('Order status updated', 'success')
    return redirect(request.referrer)

# RENAMED FUNCTION: For AJAX calls from product grid
@app.route('/update-cart-quantity', methods=['POST'])
@login_required
def update_cart_quantity_ajax():
    # Ensure user is logged in
    if not session.get('logged_in') or session.get('role') != 'user':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Invalid request'}), 400

    # Check for cart_id (from cart page) or product_id (from product page)
    cart_id = data.get('cart_id')
    product_id = data.get('product_id')
    quantity = data.get('quantity')

    if not quantity or quantity < 1:
        return jsonify({'success': False, 'message': 'Invalid quantity'}), 400

    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    success = False
    
    try:
        if cart_id:
            # Scenario 1: Updating an item already in the cart (from cart.html)
            cursor.execute('UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?', (quantity, cart_id, user_id))
            success = cursor.rowcount > 0

        elif product_id:
            # Scenario 2: Updating an item from the product listing page
            # First, find the cart entry for this user and product
            cursor.execute('SELECT id FROM cart WHERE user_id = ? AND product_id = ?', (user_id, product_id))
            cart_item = cursor.fetchone()
            if cart_item:
                cursor.execute('UPDATE cart SET quantity = ? WHERE id = ?', (quantity, cart_item['id']))
                success = cursor.rowcount > 0
            else:
                # If item doesn't exist in cart, add it
                cursor.execute('INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)', (user_id, product_id, quantity))
                success = cursor.rowcount > 0
        
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"Error updating cart quantity: {e}")
        success = False
    finally:
        conn.close()

    if success:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Failed to update quantity in database'}), 500

@app.route('/remove-from-cart', methods=['POST'])
@login_required
def remove_from_cart_ajax():
    # Ensure user is logged in
    if not session.get('logged_in') or session.get('role') != 'user':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Invalid request'}), 400

    cart_id = data.get('cart_id')
    if not cart_id:
        return jsonify({'success': False, 'message': 'Missing cart item ID'}), 400

    user_id = session.get('user_id')
    conn = get_db()
    cursor = conn.cursor()
    success = False
    
    try:
        cursor.execute('DELETE FROM cart WHERE id = ? AND user_id = ?', (cart_id, user_id))
        success = cursor.rowcount > 0
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"Error removing from cart: {e}")
        success = False
    finally:
        conn.close()

    if success:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Failed to remove item from database'}), 500

# New route to handle the buy/rent button clicks
@app.route('/buy-rent/<int:product_id>/<string:transaction_type>')
def buy_rent_product(product_id, transaction_type):
    # This route will redirect to the appropriate product detail page
    # based on whether the product is customizable or not
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT customizable FROM products WHERE id = ?', (product_id,))
    product = cursor.fetchone()
    conn.close()
    
    if not product:
        abort(404)
    
    if product['customizable']:
        # If customizable, redirect to custom product detail page
        # Pass transaction_type as a query parameter
        return redirect(url_for('custom_product_detail', product_id=product_id) + f'?transaction_type={transaction_type}')
    else:
        # If not customizable, redirect to regular product detail page
        # Pass transaction_type as a query parameter
        return redirect(url_for('product_detail', product_id=product_id) + f'?transaction_type={transaction_type}')

# Create a placeholder image directory if it doesn't exist
def create_placeholder_image():
    placeholder_dir = os.path.join(app.static_folder, 'images')
    os.makedirs(placeholder_dir, exist_ok=True)
    
    placeholder_path = os.path.join(placeholder_dir, 'product-placeholder.jpg')
    if not os.path.exists(placeholder_path):
        # Create a simple placeholder image
        try:
            from PIL import Image, ImageDraw, ImageFont
            img = Image.new('RGB', (800, 600), color='#f0f0f0')
            draw = ImageDraw.Draw(img)
            
            # Add text
            try:
                font = ImageFont.truetype("arial.ttf", 40)
            except:
                font = ImageFont.load_default()
            
            text = "Product Image"
            draw.text((400, 300), text, fill="#333333", font=font, anchor="mm")
            img.save(placeholder_path)
        except ImportError:
            # If PIL is not available, create a simple SVG file
            svg_content = '''<?xml version="1.0" encoding="UTF-8"?>
            <svg width="800" height="600" xmlns="http://www.w3.org/2000/svg">
                <rect width="800" height="600" fill="#f0f0f0"/>
                <text x="400" y="300" font-family="Arial" font-size="40" text-anchor="middle" fill="#333333">Product Image</text>
            </svg>'''
            with open(placeholder_path.replace('.jpg', '.svg'), 'w') as f:
                f.write(svg_content)

if __name__ == '__main__':
    import sys
    
    # Call this function directly when the app starts
    create_placeholder_image()
    
    if '--reset-db' in sys.argv:
        print("Command-line argument '--reset-db' detected. Resetting database...")
        if os.path.exists(DATABASE):
            os.remove(DATABASE)
            print(f"Removed old database file: {DATABASE}")
        else:
            print("No existing database file found. Creating a new one.")
        init_db()
        print("Database has been reset and initialized successfully.")
        sys.exit(0) # Exit after resetting
    else:
        # Initialize database before starting the app
        init_db()
        app.run(host='0.0.0.0', port=5000, debug=True)
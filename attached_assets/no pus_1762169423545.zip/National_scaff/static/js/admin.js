let stream = null;
let capturedImages = [];
let uploadedImages = [];
let currentImageData = null; // Add this to track the current image

function showTab(tabName, buttonElement) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    document.getElementById(tabName + '-tab').classList.add('active');
    buttonElement.classList.add('active');
}

function previewImages(event) {
    const files = event.target.files;
    const previewContainer = document.getElementById('image-preview');
    
    if (!previewContainer) {
        console.error("Preview container not found");
        return;
    }
    
    uploadedImages = [];
    previewContainer.innerHTML = '';
    
    for (let file of files) {
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const imageId = 'upload_' + Date.now() + '_' + Math.random();
                uploadedImages.push({
                    id: imageId,
                    data: e.target.result,
                    type: 'file'
                });
                
                const previewItem = document.createElement('div');
                previewItem.className = 'image-preview-item';
                previewItem.id = imageId;
                previewItem.innerHTML = `
                    <img src="${e.target.result}" alt="Preview">
                    <button type="button" class="remove-btn" onclick="removeImage('${imageId}')">×</button>
                `;
                previewContainer.appendChild(previewItem);
            }
            reader.readAsDataURL(file);
        }
    }
}

function removeImage(imageId) {
    uploadedImages = uploadedImages.filter(img => img.id !== imageId);
    capturedImages = capturedImages.filter(img => img.id !== imageId);
    const element = document.getElementById(imageId);
    if (element) element.remove();
}

function openCameraModal() {
    const modal = document.getElementById('camera-modal');
    if (modal) {
        modal.style.display = 'block';
        startCamera();
    }
}

function closeCameraModal() {
    const modal = document.getElementById('camera-modal');
    if (modal) {
        modal.style.display = 'none';
    }
    stopCamera();
    resetCameraUI();
}

function startCamera() {
    const video = document.getElementById('camera-video');
    
    if (!video) {
        console.error("Video element not found");
        return;
    }
    
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(s) {
                stream = s;
                video.srcObject = stream;
            })
            .catch(function(error) {
                console.error("Camera access error:", error);
                alert("Unable to access camera. Please check permissions.");
                closeCameraModal();
            });
    } else {
        alert("Camera API is not supported in your browser.");
        closeCameraModal();
    }
}

function stopCamera() {
    if (stream) {
        stream.getTracks().forEach(track => {
            track.stop();
        });
        stream = null;
    }
}

function resetCameraUI() {
    const video = document.getElementById('camera-video');
    const canvas = document.getElementById('camera-canvas');
    const captureBtn = document.getElementById('capture-btn');
    const retakeBtn = document.getElementById('retake-btn');
    const addMoreBtn = document.getElementById('add-more-btn');
    const usePhotosBtn = document.getElementById('use-photos-btn');
    
    if (video) video.style.display = 'block';
    if (canvas) canvas.style.display = 'none';
    if (captureBtn) captureBtn.style.display = 'inline-block';
    if (retakeBtn) retakeBtn.style.display = 'none';
    if (addMoreBtn) addMoreBtn.style.display = 'none';
    if (usePhotosBtn) usePhotosBtn.style.display = 'none';
    
    currentImageData = null; // Reset current image data
}

document.addEventListener('DOMContentLoaded', function() {
    // Capture button event
    const captureBtn = document.getElementById('capture-btn');
    if (captureBtn) {
        captureBtn.addEventListener('click', function() {
            const video = document.getElementById('camera-video');
            const canvas = document.getElementById('camera-canvas');
            
            if (!video || !canvas) {
                console.error("Video or canvas element not found");
                return;
            }
            
            const context = canvas.getContext('2d');
            
            canvas.width = video.videoWidth || 640;
            canvas.height = video.videoHeight || 480;
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            // Store current image data
            currentImageData = canvas.toDataURL('image/jpeg');
            
            video.style.display = 'none';
            canvas.style.display = 'block';
            document.getElementById('capture-btn').style.display = 'none';
            document.getElementById('retake-btn').style.display = 'inline-block';
            document.getElementById('add-more-btn').style.display = 'inline-block';
            
            if (capturedImages.length > 0) {
                document.getElementById('use-photos-btn').style.display = 'inline-block';
            }
        });
    }

    // Retake button event
    const retakeBtn = document.getElementById('retake-btn');
    if (retakeBtn) {
        retakeBtn.addEventListener('click', function() {
            resetCameraUI();
        });
    }

    // Add more button event
    const addMoreBtn = document.getElementById('add-more-btn');
    if (addMoreBtn) {
        addMoreBtn.addEventListener('click', function() {
            if (!currentImageData) {
                console.error("No current image data available");
                return;
            }
            
            const imageId = 'camera_' + Date.now() + '_' + Math.random();
            capturedImages.push({
                id: imageId,
                data: currentImageData,
                type: 'camera'
            });
            
            const capturedPhotosContainer = document.getElementById('captured-photos');
            if (capturedPhotosContainer) {
                const photoDiv = document.createElement('div');
                photoDiv.className = 'captured-photo';
                photoDiv.id = imageId;
                photoDiv.innerHTML = `
                    <img src="${currentImageData}" alt="Captured">
                    <button type="button" class="remove-photo" onclick="removeCapturedPhoto('${imageId}')">×</button>
                `;
                capturedPhotosContainer.appendChild(photoDiv);
            }
            
            resetCameraUI();
            const usePhotosBtn = document.getElementById('use-photos-btn');
            if (usePhotosBtn) {
                usePhotosBtn.style.display = 'inline-block';
            }
        });
    }

    // Use photos button event
    const usePhotosBtn = document.getElementById('use-photos-btn');
    if (usePhotosBtn) {
        usePhotosBtn.addEventListener('click', function() {
            if (!currentImageData) {
                console.error("No current image data available");
                return;
            }
            
            // Add current image to captured images
            const imageId = 'camera_' + Date.now() + '_' + Math.random();
            capturedImages.push({
                id: imageId,
                data: currentImageData,
                type: 'camera'
            });
            
            closeCameraModal();
            
            const previewContainer = document.getElementById('image-preview');
            if (previewContainer) {
                capturedImages.forEach(img => {
                    if (!document.getElementById(img.id)) {
                        const previewItem = document.createElement('div');
                        previewItem.className = 'image-preview-item';
                        previewItem.id = img.id;
                        previewItem.innerHTML = `
                            <img src="${img.data}" alt="Preview">
                            <button type="button" class="remove-btn" onclick="removeImage('${img.id}')">×</button>
                        `;
                        previewContainer.appendChild(previewItem);
                    }
                });
            }
        });
    }

    // Window click event for modal
    window.onclick = function(event) {
        const modal = document.getElementById('camera-modal');
        if (event.target == modal) {
            closeCameraModal();
        }
    }

    // Form submission event
    const addProductForm = document.querySelector('.add-product-form');
    if (addProductForm) {
        addProductForm.addEventListener('submit', function(e) {
            const allImages = [...uploadedImages, ...capturedImages];
            const imageListInput = document.getElementById('image-data-list');
            if (imageListInput) {
                imageListInput.value = JSON.stringify(allImages);
            } else {
                console.error("Image data list input not found");
            }
        });
    }
});

function removeCapturedPhoto(imageId) {
    capturedImages = capturedImages.filter(img => img.id !== imageId);
    const element = document.getElementById(imageId);
    if (element) element.remove();
    
    if (capturedImages.length === 0) {
        const usePhotosBtn = document.getElementById('use-photos-btn');
        if (usePhotosBtn) {
            usePhotosBtn.style.display = 'none';
        }
    }
}
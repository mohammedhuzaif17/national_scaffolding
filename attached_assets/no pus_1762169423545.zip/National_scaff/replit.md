# Creta Technology E-Commerce Platform

## Overview

Creta Technology is a dual-division e-commerce platform built with Flask that serves two distinct business units: National Scaffolding and CCTV Solutions. The application provides separate admin dashboards for each division and a unified user experience for browsing products, managing carts, and placing orders. The platform features role-based access control, product management with multi-image support (including camera capture), and a QR code scanner for payment processing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Framework
- **Backend**: Flask (Python web framework)
- **Template Engine**: Jinja2 for server-side rendering
- **Session Management**: Flask sessions with secret key for user authentication
- **File Upload Handling**: Werkzeug utilities for secure file uploads and password hashing

### Authentication & Authorization
- **Role-based Access Control**: Three distinct user roles
  - `admin_scaffolding`: Admin for National Scaffolding division
  - `admin_cctv`: Admin for CCTV Solutions division  
  - `user`: Regular customer accounts
- **Multi-identifier Login**: Users can authenticate using username, email, or phone number
- **Password Security**: Werkzeug's generate_password_hash and check_password_hash for secure credential storage
- **Session-based Auth**: Login state managed through Flask sessions with login_required decorator

### Data Storage
- **Database**: SQLite with `creta_technology.db` as the database file
- **Schema Design**:
  - `users`: User accounts with role, contact info, and credentials
  - `products`: Product catalog with name, price, description, category
  - `product_images`: Multiple images per product with primary image designation
  - `cart`: Shopping cart items linked to users and products
  - `orders`: Order history with status tracking
- **Relationships**: Foreign key constraints with CASCADE delete for data integrity

### Product Management
- **Multi-image Support**: Products can have multiple images with one designated as primary
- **Dual Upload Methods**: 
  - Traditional file upload from device gallery
  - Direct camera capture with base64 encoding
- **Image Processing**: Base64 data conversion and storage in static/uploads directory
- **Category Separation**: Products filtered by category (scaffolding vs cctv) for division-specific catalogs

### Frontend Architecture
- **Template Inheritance**: Base template (base.html) extended by all pages for consistent navigation and layout
- **Modal System**: Homepage modal overlay with blurred background page
- **Dynamic UI**: Tab-based admin interfaces for products and orders management
- **Image Galleries**: Product cards with main image, thumbnails, and navigation controls
- **Responsive Forms**: Multi-step image upload with preview functionality

### Routing Structure
- **Public Routes**: Index, login, register
- **User Routes**: Dashboard, product browsing (national_scaffolding, cctv_solutions), cart, orders, QR scanner
- **Admin Routes**: Division-specific dashboards (admin_scaffolding, admin_cctv) with product and order management
- **API Routes**: Cart operations (add, update, remove), checkout, product management

### File Upload System
- **Allowed Formats**: PNG, JPG, JPEG, GIF
- **Storage Location**: static/uploads directory
- **Size Limit**: 500MB max content length
- **Dual Source Handling**: 
  - File-based uploads via multipart form data
  - Base64-encoded camera captures converted to image files
- **Secure Filenames**: Werkzeug's secure_filename for sanitization

## External Dependencies

### Backend Libraries
- **Flask**: Core web framework
- **Werkzeug**: Security utilities (password hashing) and file handling
- **SQLite3**: Built-in Python database driver

### Frontend Libraries
- **html5-qrcode**: QR code scanning functionality for payment processing (v2.3.8 from unpkg CDN)
- **Google Fonts**: Playfair Display and Cormorant Garamond for typography

### Third-party Integrations
- **Camera API**: Browser's MediaDevices API for direct camera capture
- **QR Scanner**: HTML5 QR code reader for payment scanning

### Static Assets
- **CSS**: Custom styling in static/css/style.css with CSS variables for theming
- **JavaScript**: Admin functionality in static/js/admin.js for image management and UI interactions
- **Uploads Directory**: static/uploads for product images

### Environment Configuration
- **SESSION_SECRET**: Environment variable for Flask session encryption (defaults to hardcoded value if not set)
- **File System**: Automatic directory creation for upload folder on startup
# init_db.py

import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime

# Use the same database name as in your Flask app
DATABASE = 'creta_technology.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database with required tables if they don't exist"""
    conn = get_db()
    cursor = conn.cursor()
    
    # Create users table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT UNIQUE NOT NULL,
            address TEXT,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create products table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            description TEXT,
            category TEXT NOT NULL,
            subcategory TEXT,
            customizable INTEGER DEFAULT 0,
            stock_quantity INTEGER DEFAULT 0,
            available_for_rent INTEGER DEFAULT 0,
            rent_price REAL DEFAULT 0,
            security_deposit REAL DEFAULT 0,
            late_return_fine REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create product_images table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS product_images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            image_url TEXT NOT NULL,
            is_primary INTEGER DEFAULT 0,
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')
    
    # Create cart table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            transaction_type TEXT DEFAULT 'buy',
            customization TEXT,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')
    
    # Create orders table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            product_price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            total_price REAL NOT NULL,
            status TEXT DEFAULT 'pending',
            transaction_type TEXT DEFAULT 'buy',
            customization TEXT,
            username TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT,
            ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')
    
    # Check if columns exist and add them if they don't
    cursor.execute("PRAGMA table_info(products)")
    columns = [column[1] for column in cursor.fetchall()]
    
    if 'subcategory' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN subcategory TEXT")
        conn.commit()
        print("Added subcategory column to products table")
    
    if 'customizable' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN customizable INTEGER DEFAULT 0")
        conn.commit()
        print("Added customizable column to products table")
    
    if 'stock_quantity' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN stock_quantity INTEGER DEFAULT 0")
        conn.commit()
        print("Added stock_quantity column to products table")
    
    if 'available_for_rent' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN available_for_rent INTEGER DEFAULT 0")
        conn.commit()
        print("Added available_for_rent column to products table")
    
    if 'rent_price' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN rent_price REAL DEFAULT 0")
        conn.commit()
        print("Added rent_price column to products table")
    
    if 'security_deposit' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN security_deposit REAL DEFAULT 0")
        conn.commit()
        print("Added security_deposit column to products table")
    
    if 'late_return_fine' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN late_return_fine REAL DEFAULT 0")
        conn.commit()
        print("Added late_return_fine column to products table")
    
    if 'created_at' not in columns:
        cursor.execute("ALTER TABLE products ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
        conn.commit()
        print("Added created_at column to products table")
    
    # Check if columns exist in cart table
    cursor.execute("PRAGMA table_info(cart)")
    cart_columns = [column[1] for column in cursor.fetchall()]
    
    if 'transaction_type' not in cart_columns:
        cursor.execute("ALTER TABLE cart ADD COLUMN transaction_type TEXT DEFAULT 'buy'")
        conn.commit()
        print("Added transaction_type column to cart table")
    
    if 'customization' not in cart_columns:
        cursor.execute("ALTER TABLE cart ADD COLUMN customization TEXT")
        conn.commit()
        print("Added customization column to cart table")
    
    # Check if columns exist in orders table
    cursor.execute("PRAGMA table_info(orders)")
    order_columns = [column[1] for column in cursor.fetchall()]
    
    if 'transaction_type' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN transaction_type TEXT DEFAULT 'buy'")
        conn.commit()
        print("Added transaction_type column to orders table")
    
    if 'customization' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN customization TEXT")
        conn.commit()
        print("Added customization column to orders table")
    
    if 'username' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN username TEXT")
        conn.commit()
        print("Added username column to orders table")
    
    if 'email' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN email TEXT")
        conn.commit()
        print("Added email column to orders table")
    
    if 'phone' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN phone TEXT")
        conn.commit()
        print("Added phone column to orders table")
    
    if 'address' not in order_columns:
        cursor.execute("ALTER TABLE orders ADD COLUMN address TEXT")
        conn.commit()
        print("Added address column to orders table")
    
    # Create default admin user if not exists (CHECKING BY USERNAME)
    cursor.execute('SELECT * FROM users WHERE username = "admin"')
    if not cursor.fetchone():
        hashed_password = generate_password_hash('admin123')
        cursor.execute('''
            INSERT INTO users (username, email, phone, address, password, role) 
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('admin', 'admin@national-scaffolding.com', '+918105934475', 'Bengaluru, Karnataka', hashed_password, 'admin'))
        conn.commit()
        print("Created default admin user: admin / admin123")
    else:
        print("Admin user already exists.")

    # Create test user if not exists (CHECKING BY USERNAME)
    cursor.execute('SELECT * FROM users WHERE username = "test_user"')
    if not cursor.fetchone():
        hashed_password = generate_password_hash('password123')
        cursor.execute('''
            INSERT INTO users (username, email, phone, address, password, role) 
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('test_user', 'test@example.com', '+919876543212', '123 Test Street, Test City', hashed_password, 'user'))
        conn.commit()
        print("Created test user: test_user / password123")
    else:
        print("Test user already exists.")
    
    # Add sample products if none exist
    cursor.execute('SELECT COUNT(*) FROM products')
    if cursor.fetchone()[0] == 0:
        # Add sample H-Frame Product (Customizable)
        # Convert INR to USD for storage (assuming 1 USD = 83 INR)
        cursor.execute('''
            INSERT INTO products (name, price, description, category, subcategory, customizable, available_for_rent, rent_price, security_deposit, stock_quantity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', 
        ("Aluminium H-Frame (Customizable)", 1500.00/83, "High-quality, customizable aluminium H-frame for all construction needs. Perfect for versatile scaffolding solutions.", 'scaffolding', 'hframes', 1, 1, 150.00/83, 1500.00/83, 100))
        
        h_frame_id = cursor.lastrowid
        
        # Add placeholder image for H-Frame
        cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                      (h_frame_id, "static/images/product-placeholder.jpg", 1))
        
        # Add sample Cuplock Product
        cursor.execute('''
            INSERT INTO products (name, price, description, category, subcategory, customizable, available_for_rent, rent_price, security_deposit, stock_quantity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', 
        ("Cuplock System Standard", 1800.00/83, "Robust cuplock scaffolding system for high-load applications and complex structures.", 'scaffolding', 'cuplock', 0, 1, 200.00/83, 1800.00/83, 75))
        
        cuplock_id = cursor.lastrowid
        
        # Add placeholder image for Cuplock
        cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                      (cuplock_id, "static/images/product-placeholder.jpg", 1))
        
        # Add sample Aluminium Product (Non-Customizable)
        cursor.execute('''
            INSERT INTO products (name, price, description, category, subcategory, customizable, available_for_rent, stock_quantity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', 
        ("Aluminium Mobile Tower", 25000.00/83, "Complete mobile tower unit with casters for easy movement. Ready to use out of the box.", 'scaffolding', 'aluminium', 0, 0, 15))
        
        aluminium_id = cursor.lastrowid
        
        # Add placeholder image for Aluminium Tower
        cursor.execute('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)', 
                      (aluminium_id, "static/images/product-placeholder.jpg", 1))
        
        conn.commit()
        print("Added sample products")
    else:
        print("Sample products already exist.")
    
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialization complete.")